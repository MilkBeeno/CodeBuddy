# 认证模块架构规范

## 包结构

```
login/src/main/java/com/milk/codebuddy/login/
├── data/
│   ├── local/
│   │   └── SessionManager.kt          # 基于 AppPreferences 的会话管理
│   ├── model/
│   │   ├── AuthRequest.kt             # 通用请求基类
│   │   ├── BaseResponse.kt            # 通用响应包装
│   │   ├── LoginRequest.kt            # 登录请求 DTO
│   │   ├── LoginResponse.kt           # 登录响应 DTO（含 accessToken/refreshToken/userInfo）
│   │   ├── RegisterRequest.kt         # 注册请求 DTO
│   │   ├── SendCodeRequest.kt         # 发送验证码请求 DTO
│   │   ├── SendCodeResponse.kt        # 发送验证码响应 DTO
│   │   ├── ForgotPasswordVerifyRequest.kt
│   │   ├── ResetPasswordRequest.kt
│   │   └── UserSession.kt             # Domain Model（含 EMPTY 静态对象）
│   ├── remote/
│   │   └── LoginApi.kt                # Retrofit suspend 接口
│   └── repository/
│       ├── AuthRepository.kt          # 接口
│       ├── AuthRepositoryImpl.kt      # 实现
│       └── AuthRepositoryProvider.kt  # 手动 DI 单例，预留 Hilt 迁移
└── ui/
    ├── components/
    │   ├── CountdownButton.kt         # 验证码倒计时按钮组件
    │   └── LoginTextField.kt          # 统一输入框组件
    ├── navigation/
    │   ├── SplashNavigation.kt        # fun NavGraphBuilder.splashScreen()
    │   ├── LoginNavigation.kt         # fun NavGraphBuilder.loginScreen()
    │   ├── RegisterNavigation.kt      # fun NavGraphBuilder.registerScreen()
    │   ├── ForgotPasswordNavigation.kt# fun NavGraphBuilder.forgotPasswordScreen()
    │   └── ResetPasswordNavigation.kt # fun NavGraphBuilder.resetPasswordScreen()
    ├── screen/
    │   ├── SplashScreen.kt
    │   ├── LoginScreen.kt
    │   ├── RegisterScreen.kt
    │   ├── ForgotPasswordScreen.kt
    │   └── ResetPasswordScreen.kt
    ├── state/
    │   ├── LoginUiState.kt            # LoginUiState + LoginState + LoginEffect
    │   ├── RegisterUiState.kt         # RegisterUiState + RegisterState + RegisterEffect
    │   ├── ForgotPasswordUiState.kt   # ForgotPasswordUiState + ... + ForgotPasswordEffect
    │   └── ResetPasswordUiState.kt    # ResetPasswordUiState + ... + ResetPasswordEffect
    └── viewmodel/
        ├── AuthViewModelFactory.kt    # ViewModelProvider.Factory（手动 DI）
        ├── LoginViewModel.kt
        ├── RegisterViewModel.kt
        ├── ForgotPasswordViewModel.kt
        └── ResetPasswordViewModel.kt
```

---

## 分层规范

### 数据层

- `LoginApi`：所有方法必须 `suspend`，禁止返回 `Call<T>`
- `AuthRepositoryImpl`：所有网络调用用 `safeApiCall` 包装，`code != 200` 抛 `RuntimeException`
- DTO → DomainModel 转换在 Repository 层完成（UserSession 构建）
- `AuthRepositoryProvider`：手动 DI 单例，`init(context, baseUrl, isDebug)` 在 MainActivity 调用一次

### UI 层

- UiState 用 `@Immutable data class`，Error 消息用 `@StringRes Int`（资源 ID）
- State 密封类：`Idle / Loading / Success / Error(messageResId: Int)`
- Effect 密封类用 `Channel()`（非 `Channel.BUFFERED`，replay=0），`receiveAsFlow()` 暴露
- ViewModel 通过构造器注入 `AuthRepository`，由 `AuthViewModelFactory` 提供
- Screen 通过参数接收 `viewModel`（便于 Preview）
- 导航回调作为 lambda 参数传入 Screen，Screen 内部在 `LaunchedEffect` 消费 Effect

### 导航层

- 每个页面一个 `NavGraphBuilder.xxxScreen()` 扩展函数
- 在扩展函数内部用 `AuthViewModelFactory(AuthRepositoryProvider.get())` 创建 factory
- 通过 `LocalNavController.current` 获取 navController，禁止 Screen 直接持有
- 所有导航动作必须加 `launchSingleTop = true`
- 登录成功跳主页必须 `popUpTo(Login) { inclusive = true }`
- 重置密码成功后 `popUpTo(ForgotPassword) { inclusive = true }` 清除找回密码整个栈

---

## 路由表（Screen.kt）

```kotlin
@Serializable object Splash
@Serializable object Login
@Serializable object Register
@Serializable object ForgotPassword
@Serializable data class ResetPassword(val phone: String)
@Serializable object Main
```

---

## API 端点（LoginApi.kt）

```
POST api/v1/auth/send-code           sendCode(SendCodeRequest)
POST api/v1/auth/login               login(LoginRequest)
POST api/v1/auth/refresh-token       refreshToken(Map<String,String>)
POST api/v1/auth/register            register(RegisterRequest)
POST api/v1/auth/forgot-password/verify  forgotPasswordVerify(ForgotPasswordVerifyRequest)
POST api/v1/auth/reset-password      resetPassword(ResetPasswordRequest)
```

---

## base 模块依赖

| 类 | 说明 |
|---|---|
| `safeApiCall { ... }` | 网络请求统一包装，返回 `Flow<ApiResult<T>>`，内部 `flowOn(Dispatchers.IO)` |
| `ApiResult.Loading / Success / Error` | 网络结果密封类，`Error.code`：-1=超时，-2/-3=无网络 |
| `AppPreferences` | DataStore 封装，提供 `observe/put/remove/saveSession/clearSession/updateTokens` |
| `AppPreferencesKeys` | Key 常量：`ACCESS_TOKEN / REFRESH_TOKEN / IS_LOGGED_IN / USER_ID / USER_PHONE / USER_NICKNAME / USER_AVATAR` |
| `countdownFlow(totalSeconds)` | 倒计时冷流，每秒发射剩余秒数，完成后结束 |
| `DEFAULT_COUNTDOWN_SECONDS` | 默认 60 秒 |
| `String.isValidPhone()` | 手机号格式校验 |
| `LocalNavController.current` | 获取 NavController |
| `LocalAppColors.current` | 获取颜色，禁止硬编码 Color() |
| `MaterialTheme.typography` | 字体，禁止硬编码 fontSize/fontWeight |
