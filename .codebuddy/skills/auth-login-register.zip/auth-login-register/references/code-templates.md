# 认证模块代码模板

## 1. UiState + State + Effect 模板

```kotlin
package com.milk.codebuddy.login.ui.state

import androidx.compose.runtime.Immutable

@Immutable
data class XxxUiState(
    // 输入字段
    val phone: String = "",
    val code: String = "",

    // 字段错误（@StringRes Int?）
    val phoneError: Int? = null,
    val codeError: Int? = null,

    // 验证码倒计时
    val countdownSeconds: Int = 0,
    val isCountingDown: Boolean = false,

    // 请求状态
    val isLoading: Boolean = false,
    val isSendingCode: Boolean = false,

    // 业务状态
    val xxxState: XxxState = XxxState.Idle
) {
    val canSendCode: Boolean
        get() = phone.length == 11 && !isCountingDown && !isSendingCode

    val canSubmit: Boolean
        get() = phone.length == 11 && code.length == 6 && !isLoading
}

@Immutable
sealed class XxxState {
    data object Idle : XxxState()
    data object Loading : XxxState()
    data object Success : XxxState()
    data class Error(val messageResId: Int) : XxxState()
}

@Immutable
sealed class XxxEffect {
    data class ShowToast(val messageResId: Int) : XxxEffect()
    data object NavigateToXxx : XxxEffect()
    data object NavigateBack : XxxEffect()
}
```

---

## 2. ViewModel 模板

```kotlin
package com.milk.codebuddy.login.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.milk.codebuddy.base.network.ApiResult
import com.milk.codebuddy.base.utils.DEFAULT_COUNTDOWN_SECONDS
import com.milk.codebuddy.base.utils.countdownFlow
import com.milk.codebuddy.base.utils.isValidPhone
import com.milk.codebuddy.login.data.repository.AuthRepository
import com.milk.codebuddy.login.ui.state.XxxEffect
import com.milk.codebuddy.login.ui.state.XxxState
import com.milk.codebuddy.login.ui.state.XxxUiState
import com.milk.codebuddy.resource.R as ResourceR
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class XxxViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    companion object {
        private const val COUNTDOWN_SECONDS = DEFAULT_COUNTDOWN_SECONDS
        private const val PASSWORD_MIN_LENGTH = 6
        private const val PASSWORD_MAX_LENGTH = 20
    }

    private val _uiState = MutableStateFlow(XxxUiState())
    val uiState: StateFlow<XxxUiState> = _uiState.asStateFlow()

    private val _effect = Channel<XxxEffect>()
    val effect = _effect.receiveAsFlow()

    fun onPhoneChange(phone: String) {
        _uiState.update {
            it.copy(phone = phone.filter { c -> c.isDigit() }.take(11), phoneError = null)
        }
    }

    fun onCodeChange(code: String) {
        _uiState.update {
            it.copy(code = code.filter { c -> c.isDigit() }.take(6), codeError = null)
        }
    }

    fun onSendCodeClick() {
        val phone = _uiState.value.phone
        if (!phone.isValidPhone()) {
            _uiState.update { it.copy(phoneError = ResourceR.string.xxx_phone_error_format) }
            return
        }
        if (_uiState.value.isCountingDown) return

        viewModelScope.launch {
            authRepository.sendCode(phone).collect { result ->
                when (result) {
                    is ApiResult.Loading -> _uiState.update { it.copy(isSendingCode = true) }
                    is ApiResult.Success -> {
                        _uiState.update { it.copy(isSendingCode = false) }
                        startCountdown()
                    }
                    is ApiResult.Error -> _uiState.update {
                        it.copy(
                            isSendingCode = false,
                            xxxState = XxxState.Error(getErrorMessageRes(result.code))
                        )
                    }
                }
            }
        }
    }

    fun onSubmitClick() {
        if (_uiState.value.isLoading) return
        viewModelScope.launch {
            authRepository.someMethod(/* params */).collect { result ->
                when (result) {
                    is ApiResult.Loading -> _uiState.update {
                        it.copy(isLoading = true, xxxState = XxxState.Loading)
                    }
                    is ApiResult.Success -> {
                        _uiState.update {
                            it.copy(isLoading = false, xxxState = XxxState.Success)
                        }
                        _effect.send(XxxEffect.NavigateToXxx)
                    }
                    is ApiResult.Error -> _uiState.update {
                        it.copy(
                            isLoading = false,
                            xxxState = XxxState.Error(getErrorMessageRes(result.code))
                        )
                    }
                }
            }
        }
    }

    private fun startCountdown() {
        viewModelScope.launch {
            _uiState.update { it.copy(countdownSeconds = COUNTDOWN_SECONDS, isCountingDown = true) }
            countdownFlow(COUNTDOWN_SECONDS).collect { remaining ->
                _uiState.update { it.copy(countdownSeconds = remaining) }
            }
            _uiState.update { it.copy(isCountingDown = false) }
        }
    }

    private fun getErrorMessageRes(code: Int): Int = when (code) {
        401 -> ResourceR.string.xxx_error_unauthorized
        in 500..599 -> ResourceR.string.xxx_error_server
        -1 -> ResourceR.string.xxx_error_timeout
        -2, -3 -> ResourceR.string.xxx_error_network
        else -> ResourceR.string.xxx_error_unknown
    }
}
```

---

## 3. Screen 模板

```kotlin
package com.milk.codebuddy.login.ui.screen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.milk.codebuddy.login.ui.state.XxxEffect
import com.milk.codebuddy.login.ui.viewmodel.XxxViewModel

@Composable
fun XxxScreen(
    viewModel: XxxViewModel,
    modifier: Modifier = Modifier,
    onNavigateToXxx: () -> Unit = {},
    onNavigateBack: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // 消费单次事件
    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                is XxxEffect.NavigateToXxx -> onNavigateToXxx()
                is XxxEffect.NavigateBack -> onNavigateBack()
                is XxxEffect.ShowToast -> { /* context.toast(effect.messageResId) */ }
            }
        }
    }

    // UI 内容：根据 uiState 渲染
    XxxContent(
        modifier = modifier,
        uiState = uiState,
        onPhoneChange = viewModel::onPhoneChange,
        onCodeChange = viewModel::onCodeChange,
        onSendCodeClick = viewModel::onSendCodeClick,
        onSubmitClick = viewModel::onSubmitClick
    )
}

@Composable
private fun XxxContent(
    modifier: Modifier = Modifier,
    uiState: com.milk.codebuddy.login.ui.state.XxxUiState,
    onPhoneChange: (String) -> Unit,
    onCodeChange: (String) -> Unit,
    onSendCodeClick: () -> Unit,
    onSubmitClick: () -> Unit
) {
    // 布局实现
    // 颜色：LocalAppColors.current.xxx（禁止硬编码 Color()）
    // 字体：MaterialTheme.typography.xxx（禁止硬编码 fontSize）
    // 错误提示：uiState.phoneError?.let { stringResource(it) }
}
```

---

## 4. Navigation 扩展函数模板

```kotlin
package com.milk.codebuddy.login.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.milk.codebuddy.base.ui.navigation.LocalNavController
import com.milk.codebuddy.base.ui.navigation.Xxx          // 目标路由
import com.milk.codebuddy.base.ui.navigation.Yyy          // 下一页路由
import com.milk.codebuddy.login.data.repository.AuthRepositoryProvider
import com.milk.codebuddy.login.ui.screen.XxxScreen
import com.milk.codebuddy.login.ui.viewmodel.AuthViewModelFactory
import com.milk.codebuddy.login.ui.viewmodel.XxxViewModel

fun NavGraphBuilder.xxxScreen() {
    composable<Xxx> {
        val controller = LocalNavController.current
        val factory = AuthViewModelFactory(AuthRepositoryProvider.get())
        XxxScreen(
            viewModel = viewModel<XxxViewModel>(factory = factory),
            modifier = Modifier.fillMaxSize(),
            onNavigateToYyy = {
                controller.navigate(Yyy) {
                    launchSingleTop = true
                }
            },
            onNavigateBack = {
                controller.popBackStack()
            }
        )
    }
}
```

**注意**：每新增一个页面，必须在 `app` 模块的根 `NavHost` 中调用对应扩展函数注册路由。

---

## 5. AuthViewModelFactory 新增 ViewModel

当新增 ViewModel 时，在 `AuthViewModelFactory.create()` 的 `when` 中添加分支：

```kotlin
modelClass.isAssignableFrom(XxxViewModel::class.java) ->
    XxxViewModel(authRepository) as T
```

若 ViewModel 需要 `SavedStateHandle`（带参路由）：

```kotlin
modelClass.isAssignableFrom(XxxViewModel::class.java) ->
    XxxViewModel(authRepository, extras.createSavedStateHandle()) as T
```

---

## 6. 带参路由的 ViewModel

```kotlin
class XxxViewModel(
    private val authRepository: AuthRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    // 从路由中提取参数（路由定义：@Serializable data class Xxx(val phone: String)）
    private val phone: String = savedStateHandle.toRoute<Xxx>().phone

    private val _uiState = MutableStateFlow(XxxUiState(phone = phone))
    // ...
}
```

---

## 7. AuthRepositoryImpl 新增接口方法

```kotlin
// 1. 在 AuthRepository 接口中声明
fun newMethod(param: String): Flow<ApiResult<Unit>>

// 2. 在 AuthRepositoryImpl 实现
override fun newMethod(param: String): Flow<ApiResult<Unit>> = safeApiCall {
    val response = loginApi.newMethod(NewMethodRequest(param))
    if (response.code != SUCCESS_CODE) throw RuntimeException(response.message)
}

// 3. 在 LoginApi 接口中添加 suspend 方法
@POST("api/v1/auth/new-endpoint")
suspend fun newMethod(@Body request: NewMethodRequest): SendCodeResponse
```

---

## 8. SessionManager / UserSession

```kotlin
// UserSession DomainModel
data class UserSession(
    val accessToken: String = "",
    val refreshToken: String = "",
    val userId: String = "",
    val phone: String = "",
    val nickname: String = "",
    val avatar: String = "",
    val isLoggedIn: Boolean = false
) {
    companion object {
        val EMPTY = UserSession()
    }
}

// 登录成功后保存会话
sessionManager.saveSession(
    UserSession(
        accessToken = tokenData.accessToken,
        refreshToken = tokenData.refreshToken,
        userId = userInfo?.userId.orEmpty(),
        phone = userInfo?.phone ?: phone,
        nickname = userInfo?.nickname.orEmpty(),
        avatar = userInfo?.avatar.orEmpty(),
        isLoggedIn = true
    )
)
```

---

## 9. 错误码映射规范

```kotlin
private fun getErrorMessageRes(code: Int): Int = when (code) {
    401   -> ResourceR.string.xxx_error_unauthorized   // 未授权
    403   -> ResourceR.string.xxx_error_forbidden      // 禁止访问
    in 500..599 -> ResourceR.string.xxx_error_server   // 服务端错误
    -1    -> ResourceR.string.xxx_error_timeout        // 超时（ApiResult.Error.TIMEOUT）
    -2, -3 -> ResourceR.string.xxx_error_network       // 无网络 / IO 错误
    else  -> ResourceR.string.xxx_error_unknown        // 未知
}
```

---

## 10. 认证流程总览

### 登录流程
```
SplashScreen → 检查 SessionManager.isLoggedIn()
  ├─ true  → navigate(Main) { popUpTo(Splash) inclusive }
  └─ false → navigate(Login) { popUpTo(Splash) inclusive }

LoginScreen
  ├─ 输入手机号 + 验证码
  ├─ 点击「发送验证码」→ LoginViewModel.onSendCodeClick() → authRepository.sendCode()
  │    成功 → startCountdown()（countdownFlow(60)）
  ├─ 点击「登录」→ LoginViewModel.onLoginClick() → authRepository.login()
  │    成功 → sessionManager.saveSession() → LoginEffect.NavigateToMain
  │         → navigate(Main) { popUpTo(Login) inclusive }
  ├─ 点击「注册」→ navigate(Register)
  └─ 点击「忘记密码」→ navigate(ForgotPassword)
```

### 注册流程
```
RegisterScreen
  ├─ 输入手机号 + 验证码 + 密码 + 确认密码
  ├─ 点击「发送验证码」→ authRepository.sendCode() + 倒计时
  └─ 点击「注册」→ authRepository.register()
       成功 → RegisterEffect.ShowToast + RegisterEffect.NavigateToLogin
            → controller.popBackStack()
```

### 忘记密码流程
```
ForgotPasswordScreen
  ├─ 输入手机号 + 验证码
  └─ 点击「下一步」→ authRepository.forgotPasswordVerify()
       成功 → ForgotPasswordEffect.NavigateToResetPassword(phone)
            → navigate(ResetPassword(phone)) { launchSingleTop }

ResetPasswordScreen（接收 phone 参数）
  ├─ ViewModel 通过 savedStateHandle.toRoute<ResetPassword>().phone 获取 phone
  ├─ 输入新密码 + 确认密码
  └─ 点击「提交」→ authRepository.resetPassword(phone, newPassword, confirmPassword)
       成功 → ResetPasswordEffect.ShowToast + ResetPasswordEffect.NavigateToLogin
            → navigate(Login) { popUpTo(ForgotPassword) inclusive }
```
